package dummy_test;

import dummy.EmailService;

public class DummyEmailService implements EmailService{

	@Override
	public void sendEmail(String message) {
		throw new AssertionError("Method not implement");
	}

}
