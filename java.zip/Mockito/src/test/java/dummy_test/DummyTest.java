package dummy_test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import dummy.EmailService;
import fake.Book;
import fake.BookRepoistory;
import fake.BookService;
import fake_test.FakeBookRepository;

public class DummyTest {
	@Test
	public void demoDummy() {
		BookRepoistory bookRepoistory = new FakeBookRepository();
		EmailService emailService = new DummyEmailService();
		BookService bookService = new BookService(bookRepoistory, emailService);
		
		bookService.addBook(new Book("1234", "Mockito in Action", 250, LocalDate.now()));
		bookService.addBook(new Book("1235", "JUnit 5 in Action", 200, LocalDate.now()));
		bookService.addBook(new Book("2235", "JUnit 5 & Mockito in Action", 550, LocalDate.now()));
		
		assertEquals(3, bookService.findNumberOfBook());
	}

}
