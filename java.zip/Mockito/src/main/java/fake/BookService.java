package fake;

import dummy.EmailService;

public class BookService {
	private BookRepoistory bookRepository;

	public BookService(BookRepoistory bookRepository, EmailService emailService) {
		super();
		this.bookRepository = bookRepository;
	}
	public void addBook(Book book) {
		bookRepository.save(book);
	}
	
	public int findNumberOfBook() {
		return bookRepository.findAll().size();
	}
}
