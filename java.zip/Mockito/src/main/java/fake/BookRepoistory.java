package fake;

import java.util.Collection;

public interface BookRepoistory {
	void save(Book book);
	Collection<Book> findAll();
}
