package dummy;

public class BookService {
	private BookRepoistory bookRepository;
	private EmailService emailService;

	
	public BookService(BookRepoistory bookRepository, EmailService emailService) {
		super();
		this.bookRepository = bookRepository;
		this.emailService = emailService;
	}

	public void addBook(Book book) {
		bookRepository.save(book);
	}
	
	public int findNumberOfBook() {
		return bookRepository.findAll().size();
	}
}
