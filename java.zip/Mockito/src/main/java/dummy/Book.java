package dummy;

import java.time.LocalDate;

public class Book {
	private String bookId;
	private String title;
	private int price;
	private LocalDate publisherDate;
	public Book(String bookId, String title, int price, LocalDate publisherDate) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.price = price;
		this.publisherDate = publisherDate;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public LocalDate getPublisherDate() {
		return publisherDate;
	}
	public void setPublisherDate(LocalDate publisherDate) {
		this.publisherDate = publisherDate;
	}
	

}
