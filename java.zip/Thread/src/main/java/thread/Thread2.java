package thread;

import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Thread2 extends Thread {
//	ArrayList<Character> list = new ArrayList<Character>();
	ShareData shareData;

	public Thread2(ShareData shareData) {
		this.shareData = shareData;
	}

	@Override
	public void run() {
//		int min = (int) 'a';
//		int max = (int) 'z';
//		int limit = max - min;
//		Random random = new Random();
//		for (int i = 0; i < 10; i++) {
//			int rad = random.nextInt(limit) + min;
//			char c = (char) rad;
//			list.add(c);
//			System.out.println("t2 > " + c);
//			try {
//				Thread.sleep(200);
//			} catch (InterruptedException ex) {
//				Logger.getLogger(Thread2.class.getName()).log(Level.SEVERE, null, ex);
//			}
//		}
		for (int i = 0; i < 10; i++) {
			synchronized (shareData) {
				try {
					shareData.wait();
				} catch (InterruptedException ex) {
					Logger.getLogger(Thread1.class.getName()).log(Level.SEVERE, null, ex);
				}
				int result = shareData.rad * shareData.rad;
				System.out.println("t2 > " + result);
				shareData.notifyAll();
			}
		}
	}
}
