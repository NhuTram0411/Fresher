package thread;

import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Thread1 extends Thread {
//	ArrayList<Integer> list = new ArrayList<Integer>();
	ShareData shareData;

	public Thread1(ShareData shareData) {
		this.shareData = shareData;
	}

	@Override
	public void run() {
		Random random = new Random();
		for (int i = 0; i < 10; i++) {
			synchronized (shareData) {

				int rad = random.nextInt(100);
				shareData.rad = rad;
//				list.add(rad);
				System.out.println("t1 > " + rad);
//				try {
//					Thread.sleep(100);
//				} catch (InterruptedException ex) {
//					Logger.getLogger(Thread2.class.getName()).log(Level.SEVERE, null, ex);
//				}
				shareData.notifyAll();
				try {
					shareData.wait();
				} catch (InterruptedException ex) {
					Logger.getLogger(Thread1.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
	}
}
