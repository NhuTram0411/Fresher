package thread;

public class Main {

	public static void main(String[] args) throws InterruptedException {
//		Thread1 t1 = new Thread1();
//		Thread2 t2 = new Thread2();
//		t1.start();
//		t2.start();
//
//		t1.join();
//		t2.join();
//
//		System.out.println("random thread t1 and t2: ");
//		System.out.println("T1: ");
//		for (int i = 0; i < t1.list.size(); i++) {
//			System.out.println(" " + t1.list.get(i));
//		}
//		System.out.println("\\nT2: ");
//		for (int i = 0; i < t2.list.size(); i++) {
//			System.out.println(" " + t2.list.get(i));
//		}
		ShareData shareData = new ShareData();
		CustomThread thread1 = new CustomThread(shareData);
		CustomThread thread2 = new CustomThread(shareData);
		CustomThread thread3 = new CustomThread(shareData);
		CustomThread thread4 = new CustomThread(shareData);
		CustomThread thread5 = new CustomThread(shareData);
		thread1.start();
		thread2.start();
		thread3.start();
		thread4.start();
		thread5.start();
	}

}
