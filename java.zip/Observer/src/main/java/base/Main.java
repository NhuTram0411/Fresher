package base;

import Publisher.MessagePublisher;
import Subscribe.MessageSubcribrOne;
import Subscribe.MessageSubcribrThree;
import Subscribe.MessageSubcribrTwo;

public class Main {

	public static void main(String[] args) {
		MessageSubcribrOne one = new MessageSubcribrOne();
		MessageSubcribrTwo two = new MessageSubcribrTwo();
		MessageSubcribrThree three = new MessageSubcribrThree();

		MessagePublisher m = new MessagePublisher();

		m.register(one);
		m.register(two);
		m.remove(three);

		m.update(new Message("First Message"));

		m.remove(one);
		m.register(three);

		m.update(new Message("Second Message"));
	}

}
