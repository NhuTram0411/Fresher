package base;

public interface Observer {
	void update(Message m);
}
