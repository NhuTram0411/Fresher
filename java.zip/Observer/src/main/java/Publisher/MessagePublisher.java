package Publisher;

import base.Subject;
import java.util.ArrayList;
import base.Message;
import base.Observer;

public class MessagePublisher implements Subject {
	private ArrayList<Observer> observers = new ArrayList<Observer>();

	public void register(Observer o) {
		observers.add(o);
	}

	public void remove(Observer o) {
		observers.remove(o);

	}

	public void update(Message m) {
		for(Observer o : observers) {
			o.update(m);
		}

	}

}
