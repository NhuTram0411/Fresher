package Subscribe;

import base.Message;
import base.Observer;

public class MessageSubcribrOne implements Observer {

	public void update(Message m) {
		System.out.println("MessageSubcribrOne :: " + m.getMessageContent());

	}

}
