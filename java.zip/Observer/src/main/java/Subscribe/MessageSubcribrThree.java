package Subscribe;

import base.Message;
import base.Observer;

public class MessageSubcribrThree implements Observer {

	public void update(Message m) {
		System.out.println("MessageSubcribrThree :: " + m.getMessageContent());
	}

}
