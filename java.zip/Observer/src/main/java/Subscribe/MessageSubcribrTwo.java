package Subscribe;

import base.Message;
import base.Observer;

public class MessageSubcribrTwo implements Observer {

	public void update(Message m) {
		System.out.println("MessageSubcribrTwo :: " + m.getMessageContent());

	}

}
