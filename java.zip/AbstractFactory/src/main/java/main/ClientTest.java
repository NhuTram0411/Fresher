package main;
import demo.*;

public class ClientTest {

	public static void main(String[] args) {
		ElectronicDeviceAbstractFactory hightEndFactory = ElectronicDeviceFactory.getFactory(Segment.HIGHT_END);
		Laptop hightEndLaptop = hightEndFactory.getLaptop();
		Phone hightEndPhone = hightEndFactory.getPhone();
		System.out.println(hightEndPhone.getSegment());
		System.out.println(hightEndLaptop.getSegment());
		System.out.println("============================");
		
		ElectronicDeviceAbstractFactory midRangeFactory = ElectronicDeviceFactory.getFactory(Segment.MID_RANGE);
		Laptop midRangeLaptop = midRangeFactory.getLaptop();
		Phone midRangePhone = midRangeFactory.getPhone();
		System.out.println(midRangeLaptop.getSegment());
		System.out.println(midRangePhone.getSegment());
		System.out.println("============================");
		
		ElectronicDeviceAbstractFactory ASUSFactory = ElectronicDeviceFactory.getFactory(Segment.ASUS);
		Laptop ASUSLaptop = ASUSFactory.getLaptop();
		Phone ASUSPhone = ASUSFactory.getPhone();
		System.out.println(ASUSLaptop.getSegment());
		System.out.println(ASUSPhone.getSegment());
	}
}
