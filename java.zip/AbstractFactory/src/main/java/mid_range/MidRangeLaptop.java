package mid_range;

import demo.Laptop;

public class MidRangeLaptop implements Laptop{

	public String getSegment() {
		return "Mid_range laptop";
	}
}
