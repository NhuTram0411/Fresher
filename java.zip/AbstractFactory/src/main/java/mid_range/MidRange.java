package mid_range;

import demo.Phone;

public class MidRange implements Phone{

	public String getSegment() {
		return "Mid_range phone";
	}

}
