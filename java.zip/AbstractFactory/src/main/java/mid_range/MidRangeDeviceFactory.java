package mid_range;

import demo.ElectronicDeviceAbstractFactory;
import demo.Laptop;
import demo.Phone;

public class MidRangeDeviceFactory extends ElectronicDeviceAbstractFactory {

	@Override
	public Phone getPhone() {
		return new MidRange();
	}

	@Override
	public Laptop getLaptop() {
		return new MidRangeLaptop();
	}

}
