package demo;

public interface Laptop {
	String getSegment();
}
