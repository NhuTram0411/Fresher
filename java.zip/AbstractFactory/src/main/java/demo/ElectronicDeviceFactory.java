package demo;
import ASUS.ASUSDeviceFactory;
import hight_end.HightEndDeviceFactory;
import mid_range.MidRangeDeviceFactory;
public class ElectronicDeviceFactory {
	public static ElectronicDeviceAbstractFactory getFactory(Segment segment) {
		switch (segment) {
		case MID_RANGE:
			return new MidRangeDeviceFactory();
		case HIGHT_END:
			return new HightEndDeviceFactory();
		case ASUS:
			return new ASUSDeviceFactory();
		default:
			throw new UnsupportedOperationException("This device is unsupported");
		}
	}
}
