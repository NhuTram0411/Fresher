//package demo;

public enum Segment {
	MID_RANGE, HIGHT_END, ASUS;
}
