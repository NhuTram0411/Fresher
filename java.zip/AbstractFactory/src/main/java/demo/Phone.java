package demo;

public interface Phone {
	String getSegment();
}
