package demo;

public abstract class ElectronicDeviceAbstractFactory {
	public abstract Phone getPhone();
	public abstract Laptop getLaptop();
}
