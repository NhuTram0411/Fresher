package hight_end;

import demo.ElectronicDeviceAbstractFactory;
import demo.Laptop;
import demo.Phone;

public class HightEndDeviceFactory extends ElectronicDeviceAbstractFactory{

	@Override
	public Phone getPhone() {
		return new HightEndPhone();
	}

	@Override
	public Laptop getLaptop() {
		return new HightEndLaptop();
	}

}
