package hight_end;

import demo.Phone;

public class HightEndPhone implements Phone{

	public String getSegment() {
		return "Hight_End phone";
	}

}
