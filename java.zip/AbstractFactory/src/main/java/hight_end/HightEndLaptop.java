package hight_end;

import demo.Laptop;

public class HightEndLaptop implements Laptop{

	public String getSegment() {
		return "Hight_End laptop";
	}

}
