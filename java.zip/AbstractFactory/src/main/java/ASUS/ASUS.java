package ASUS;

import demo.Phone;

public class ASUS implements Phone{
	public String getSegment() {
		return "ASUS phone";
	}
}
