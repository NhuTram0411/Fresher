package ASUS;

import demo.ElectronicDeviceAbstractFactory;
import demo.Laptop;
import demo.Phone;

public class ASUSDeviceFactory extends ElectronicDeviceAbstractFactory {

	@Override
	public Phone getPhone() {
		return new ASUS();
	}

	@Override
	public Laptop getLaptop() {
		return new ASUSLaptop();
	}

}