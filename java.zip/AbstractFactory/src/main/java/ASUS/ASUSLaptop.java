package ASUS;

import demo.Laptop;

public class ASUSLaptop implements Laptop {
	
	public String getSegment() {
		return "ASUS laptop";
	}
}
