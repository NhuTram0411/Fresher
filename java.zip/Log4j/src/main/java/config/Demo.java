package config;

//import java.io.IOException;
//import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Demo {
	static Logger logger = LogManager.getLogger(Demo.class);
    public static void main(String[] args) {
    	System.out.print("\n Hello world...! \n");
    	logger.trace("Trace");
        logger.info("info");
        logger.warn("warn");
        logger.error("error");
        logger.fatal("this is fatal");
        System.out.print("complete");
    }
}

