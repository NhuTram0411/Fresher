package base;

public class ChargerAdaptee {
	public void plug() {
		System.out.println("Nokia");
		System.out.println("SamSung");
		System.out.println("Apple");
		System.out.println("Asus");
	}
}
