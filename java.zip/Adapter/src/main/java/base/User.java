package base;

public class User {
	public void charger() {
		ChargerAdapter c = new ChargerAdapter();
		c.charger();
	}
}
