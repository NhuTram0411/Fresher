package base;

public class ChargerAdapter {
	private ChargerAdaptee adaptee;
	public void charger() {
		adaptee = new ChargerAdaptee();
		adaptee.plug();
		
	}
}
