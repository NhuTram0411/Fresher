package collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class collection {

	/**
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(3);
		arr.add(3);
		arr.add(4);
		System.out.print(arr + "\n");
		HashSet<Integer> arr1 = new HashSet<Integer>();
		arr1.add(3);
		arr1.add(3);
		arr1.add(4);
		System.out.print(arr1 + "\n");
		HashMap<Integer, String> arr2 = new HashMap<Integer, String>();
		arr2.put(2, "English");
		arr2.put(3, "Japan");
		arr2.put(4, "English");
//		arr1.add(3);
//		arr1.add(4);
		System.out.print(arr2 + "\n");

		Generic<String> type = new Generic<String>("Nhu Tram");
//		type.setT("Nhu Tram");
//		type.setT(21);
		System.out.println(type + "\n");
	}
}
