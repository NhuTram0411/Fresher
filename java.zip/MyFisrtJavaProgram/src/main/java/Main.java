import java.io.*;
import java.util.Scanner;

public class Main {
	
	public static void Thue(double salary) {
		double thueDong = 0;
		if (salary >= 10000) {
			thueDong = salary * 0.05;
			System.out.print("Thue thu nhap ca nhan phai dong : " + thueDong);
		} else
			System.out.print("Chua can dong thue thu nhap ca nhan!");
	}

	public static void main(String[] args) {
		 try {
			 
	            File file = new File("D:\\newfile.txt");
	 
	            if (file.createNewFile()) {
	                System.out.println("File is created!");
	            } else {
	                System.out.println("File already exists.");
	            }
	 
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		double salary;
		Employee emp = new Employee("Tram", 18, true, 1000);
		emp.printE();
		Scanner sc = new Scanner(System.in);
		System.out.print("\nVui long nhap vao muc thu nhap : ");
		salary = sc.nextDouble();
		Thue(salary);
	}
}