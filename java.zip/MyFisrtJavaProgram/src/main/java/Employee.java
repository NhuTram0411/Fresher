import java.io.*;

public class Employee {
	String name;
	int age;
	boolean sex;
	double salary;

	public Employee(String name, int age, boolean sex, double salary) {
		super();
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isSex() {
		return sex;
	}

	public void setSex(boolean sex) {
		this.sex = sex;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String gt(boolean sex) {
		String gt;
		if (sex = true) {
			gt = "female";
		}
		else {
			gt = "male";
		}
		return gt;
	}
	
	public void printE() {
		System.out.print("Employee \n [name=" + name + "\n" + " age=" + age + "\n" + " sex=" + gt(sex) + "\n" 
				+ " salary=" + salary + "\n" + "]");
	}

}
