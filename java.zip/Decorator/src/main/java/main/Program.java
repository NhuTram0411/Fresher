package main;

import decorator.*;
import base.*;

public class Program {

	public static void main(String[] args) {
		IMilkTea milkTea = new EggPudding(new FruitPudding(new MilkTea()));
		System.out.println(milkTea.Cost());
	}

}
