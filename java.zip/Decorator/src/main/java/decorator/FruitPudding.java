package decorator;

import base.IMilkTea;
import base.MilkTeaDecorator;

public class FruitPudding extends MilkTeaDecorator {

	public FruitPudding(IMilkTea inner) {
		super(inner);
	}

	@Override
	public double Cost() {
		return 4d + super.Cost();
	}
}
