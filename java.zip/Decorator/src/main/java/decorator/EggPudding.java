package decorator;

import base.IMilkTea;
import base.MilkTeaDecorator;

public class EggPudding extends MilkTeaDecorator {

	public EggPudding(IMilkTea inner) {
		super(inner);
	}

	@Override
	public double Cost() {
		return 10d + super.Cost();
	}
}
