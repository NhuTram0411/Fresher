package decorator;

import base.IMilkTea;
import base.MilkTeaDecorator;

public class WhiteBubble extends MilkTeaDecorator {

	protected WhiteBubble(IMilkTea inner) {
		super(inner);
	}

	@Override
	public double Cost() {
		return 5d + super.Cost();
	}

}
