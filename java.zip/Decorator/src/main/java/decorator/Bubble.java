package decorator;

import base.IMilkTea;
import base.MilkTeaDecorator;

public class Bubble extends MilkTeaDecorator{

	protected Bubble(IMilkTea inner) {
		super(inner);
	}

	@Override
	public double Cost() {
		return 1d + super.Cost();
	}
	

}
