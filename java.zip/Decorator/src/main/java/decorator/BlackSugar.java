package decorator;

import base.IMilkTea;
import base.MilkTeaDecorator;

public class BlackSugar extends MilkTeaDecorator {

	protected BlackSugar(IMilkTea inner) {
		super(inner);
	}

	@Override
	public double Cost() {
		return 3d + super.Cost();
	}

}