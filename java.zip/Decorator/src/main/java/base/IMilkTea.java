package base;

public interface IMilkTea {
	double Cost();

}
