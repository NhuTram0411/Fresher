package base;

public abstract class MilkTeaDecorator implements IMilkTea{

	public IMilkTea _milktea;
	
	
	protected MilkTeaDecorator(IMilkTea inner) {
		_milktea = inner;
	}


	public double Cost() {
		return _milktea.Cost();
	}

}
