package base;

public class MilkTea implements IMilkTea{

	public double Cost() {
		return 5d;
	}

}
